INSERT INTO todo (ID, USERNAME, DESCRIPTION, TARGET_DATE, DONE) 
VALUES (10001, 'VAGA', 'Get AWS certified', CURRENT_DATE(), false);

INSERT INTO todo (ID, USERNAME, DESCRIPTION, TARGET_DATE, DONE) 
VALUES (10002, 'JOHN', 'Complete Java project', CURRENT_DATE(), false);

INSERT INTO todo (ID, USERNAME, DESCRIPTION, TARGET_DATE, DONE) 
VALUES (10003, 'EMMA', 'Start Spring Boot course', CURRENT_DATE(), false);

INSERT INTO todo (ID, USERNAME, DESCRIPTION, TARGET_DATE, DONE) 
VALUES (10004, 'MIKE', 'Prepare for Kubernetes exam', CURRENT_DATE(), false);

INSERT INTO todo (ID, USERNAME, DESCRIPTION, TARGET_DATE, DONE) 
VALUES (10005, 'LISA', 'Read design patterns book', CURRENT_DATE(), false);

INSERT INTO todo (id, username, description, target_date, done) 
VALUES (10006, 'rrr', 'Test todo for rrr', CURRENT_DATE, false);

INSERT INTO todo (id, username, description, target_date, done) 
VALUES (10007, 'rrr', 'Test todo for rrr', CURRENT_DATE, false);

INSERT INTO todo (id, username, description, target_date, done) 
VALUES (10008, 'rrr', 'Test todo for rrr', CURRENT_DATE, false);

INSERT INTO todo (id, username, description, target_date, done) 
VALUES (10009, 'rrr', 'Test todo for rrr', CURRENT_DATE, false);
